package ivanmartinez.simpleStudentsAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleStudentsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleStudentsApiApplication.class, args);
	}

}
