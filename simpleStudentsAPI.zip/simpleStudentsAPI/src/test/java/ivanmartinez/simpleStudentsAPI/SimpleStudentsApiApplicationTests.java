package ivanmartinez.simpleStudentsAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleStudentsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
